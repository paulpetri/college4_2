/*********************************************************/
/*** Date : Dec, 12th, 2011                            ***/
/*** Description: Main class to start the program      ***/
/*********************************************************/

public class ASMain
{
	public static void main(String args[])
	{
		new ASFrame("Meng Cui");
	}
}